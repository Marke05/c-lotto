﻿namespace lotto
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.idkeres = new System.Windows.Forms.TextBox();
            this.felhasznalokeres = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.adatlista = new System.Windows.Forms.ListBox();
            this.feladat9 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(105, 119);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "keres";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // idkeres
            // 
            this.idkeres.Location = new System.Drawing.Point(105, 32);
            this.idkeres.Name = "idkeres";
            this.idkeres.Size = new System.Drawing.Size(100, 22);
            this.idkeres.TabIndex = 1;
            // 
            // felhasznalokeres
            // 
            this.felhasznalokeres.Location = new System.Drawing.Point(105, 79);
            this.felhasznalokeres.Name = "felhasznalokeres";
            this.felhasznalokeres.Size = new System.Drawing.Size(100, 22);
            this.felhasznalokeres.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(19, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "id";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "felhasznalo";
            // 
            // adatlista
            // 
            this.adatlista.FormattingEnabled = true;
            this.adatlista.ItemHeight = 16;
            this.adatlista.Location = new System.Drawing.Point(223, 32);
            this.adatlista.Name = "adatlista";
            this.adatlista.Size = new System.Drawing.Size(497, 452);
            this.adatlista.TabIndex = 5;
            // 
            // feladat9
            // 
            this.feladat9.FormattingEnabled = true;
            this.feladat9.ItemHeight = 16;
            this.feladat9.Location = new System.Drawing.Point(738, 32);
            this.feladat9.Name = "feladat9";
            this.feladat9.Size = new System.Drawing.Size(506, 452);
            this.feladat9.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1346, 534);
            this.Controls.Add(this.feladat9);
            this.Controls.Add(this.adatlista);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.felhasznalokeres);
            this.Controls.Add(this.idkeres);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox idkeres;
        private System.Windows.Forms.TextBox felhasznalokeres;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox adatlista;
        private System.Windows.Forms.ListBox feladat9;
    }
}

