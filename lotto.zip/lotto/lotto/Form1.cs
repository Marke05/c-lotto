﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lotto
{
    public partial class Form1 : Form
    {
        List<string> adatok = new List<string>();
        List<string> users = new List<string>();
        public Form1()
        {
            string[] lines = File.ReadAllLines("adat.txt");
            foreach (var item in lines)
            {
                string[] values = item.Split(';');
                adatok.Add(item);
                users.Add(values[1]);
            }
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            adatlista.Items.Clear();
            feladat9.Items.Clear();
            //feladat 1
            string keresetid = idkeres.Text;
            string idkeresadatok = "";
            foreach (var items in adatok)
            {
                string[] values = items.Split(';');
                if (keresetid == values[0]) { idkeresadatok = "nev: " + values[1] + " fizetve: " + values[2] + "ft" + " szorzo: " + values[3] + " eredmeny: " + values[4]; }
                else if (idkeresadatok == "") { idkeresadatok = "ilen sorszam nincs"; }
            }
            adatlista.Items.Add("1 feladat");
            adatlista.Items.Add(idkeresadatok);

            //feladat 2
            string keresnev = "";
            int nevszamol = 0;
            int oszeg = 0;
            foreach (var i in users)
            {
                int a = 0;
                foreach (var j in users)
                {
                    if (i == j) { a++; }
                }
                if (a > nevszamol)
                {
                    nevszamol = a;
                    keresnev = i;
                }
            }
            foreach (var item in adatok)
            {
                string[] values = item.Split(';');
                if (keresnev == values[1]) { oszeg += Convert.ToInt32(values[2]); }
            }
            adatlista.Items.Add("2 feladat");
            adatlista.Items.Add(keresnev + " jatszot korok " + nevszamol + " koltot ra " + oszeg + " ft");

            //feladat 3
            int vesztes = 0;
            foreach (var items in adatok)
            {
                string[] values = items.Split(';');
                if (values[4] == "vesztes") { vesztes++; }
            }
            adatlista.Items.Add("3 feladat");
            adatlista.Items.Add("vesztes korok: " + vesztes);

            //feladat 4
            int legkisebb = 1000000000;
            string legkisebbadatok = "";
            foreach (var items in adatok)
            {
                string[] values = items.Split(';');
                if (values[4] == "nyertes")
                {
                    int a = Convert.ToInt32(values[2]);
                    int b = Convert.ToInt32(values[3]);
                    int c = a * b;
                    if (c < legkisebb)
                    {
                        legkisebb = c;
                        legkisebbadatok = "sorszam: " + values[0] + ", nev: " + values[1] + ", befizetet penz: " + values[2] + "ft," + " szorzo: " + values[3] + ", eredmeny: " + values[4];
                    }
                }
            }
            adatlista.Items.Add("4 feladat");
            adatlista.Items.Add(legkisebbadatok);

            //feladat 5
            string felhasznalo = felhasznalokeres.Text;
            List<string> feladatok = new List<string>();
            foreach (var items in adatok)
            {
                string[] values = items.Split(';');
                if (felhasznalo == values[1]) { feladatok.Add("sorszam: " + values[0] + ", nev: " + values[1] + ", befizetet penz: " + values[2] + "ft," + " szorzo: " + values[3] + ", eredmeny: " + values[4]); }
            }
            adatlista.Items.Add("5 feladat");
            if (feladatok.Count <= 0) { adatlista.Items.Add("nincs adat"); }
            else
            {
                foreach (var items in feladatok)
                {
                    adatlista.Items.Add(items);
                }
            }

            //feladat 6
            List<string> abetus = new List<string>();
            foreach (var items in users)
            {
                string betu = items.Substring(0, 1);
                if (betu == "a") { abetus.Add(items); }
            }
            adatlista.Items.Add("6 feladat");
            for (int i = 0; i < 5; i++)
            {
                adatlista.Items.Add(abetus[i]);
            }
            adatlista.Items.Add("a betuvel kezdodo nevek: " + abetus.Count);

            //feladat 7
            int decnyereseg = 0;
            foreach (var items in adatok)
            {
                string[] values = items.Split(';');
                if (values[1] == "decongen")
                {
                    if (values[4] == "nyertes")
                    {
                        decnyereseg -= Convert.ToInt32(values[2]);
                        decnyereseg += Convert.ToInt32(values[2]) * Convert.ToInt32(values[3]);
                    }
                    else if (values[4] == "vesztes")
                    {
                        decnyereseg -= Convert.ToInt32(values[2]);
                    }
                }
            }
            adatlista.Items.Add("7 feladat");
            adatlista.Items.Add("decongen nyeresege: " + decnyereseg + "ft");

            //feladat 8
            int nyertoszeg = 0;
            foreach (var items in adatok)
            {
                string[] values = items.Split(';');
                if (values[4] == "nyertes")
                {
                    nyertoszeg += Convert.ToInt32(values[2]) * Convert.ToInt32(values[3]);
                }
            }
            adatlista.Items.Add("8 feladat");
            adatlista.Items.Add("nyeresegek oszege: " + nyertoszeg + "ft");

            //feladat 9
            adatlista.Items.Add("9 feladat");
            foreach (var items in adatok)
            {
                int nyereseg = 0;
                string[] values = items.Split(';');
                if (values[4] == "nyertes")
                {
                    nyereseg += Convert.ToInt32(values[2]) * Convert.ToInt32(values[3]);
                    feladat9.Items.Add("sorszam: " + values[0] + " neve: " + values[1] + " nyeremeny oszege: " + nyereseg + "ft");
                }
            }

        }
    }
}
